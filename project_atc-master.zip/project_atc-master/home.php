<?php
echo "WELCOME!"; ?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>papa fare</title>
  </head>
  <body>
    <style>
body {
  background-image: url('images/bg.jpg');
}
</style>
    <p style="color:white; text-align:center; font-size:140%">[Teksti i "Soni & Nesti ft. Genard Hajdini, Donald - Calma"]

<br>Afrou ti o dalëngadale
Me le, me le pa fjale
Lale hajde ti dalëngadale

<br>


<br> Hajde gjuje ti, gjuje nga nji fjale
Pak me dashni,  O menjemadhe
Hajde lali hajde ti dalëngadale

<br>Hajde ti te danoci papa fare
Gjona t'mira
Gjona t'bukra te danoci ke
Ah papa fare

<br>


<br>Hajde falma zemren falma  (x4)
Vetem calma te quiero un te du
T'kam per vete vec per vete
Na na na e ke, se ke me mu

<br>Hajde ti te danoci papa fare
Gjona t'mira
Gjona t'bukra te danoci ke
Ah papa fare

<br>

<br> Hajde falma zemren falma  (x4)
Vetem calma te quiero un te du
T'kam per vete vec per vete
Na na na e ke, se ke me mu.</p>
<a style="color:white;" target="_blank" href="https://www.youtube.com/watch?v=eemsL2lxGos">Song</a>

  </body>
</html>
