<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "project";

$conn = new mysqli($servername,$username,$password,$database);

if ($conn === false) {
  die("Couldn't" . $conn->connect_error);
}






$conn

 ?>
